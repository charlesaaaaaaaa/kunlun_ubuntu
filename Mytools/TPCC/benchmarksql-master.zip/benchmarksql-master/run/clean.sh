rm -rf log/

mkdir -p log/archive


